# información
Los 4 ejercicios de la guía 2 están en una sola aplicación y podrá usar el menú para ir cambiando los layouts y poder ver cada uno de los ejercicios, el ejercicio 1 que es donde se pide mostrar el letrero de bienvenida es el layout principal por eso no se encuentra en el menú
